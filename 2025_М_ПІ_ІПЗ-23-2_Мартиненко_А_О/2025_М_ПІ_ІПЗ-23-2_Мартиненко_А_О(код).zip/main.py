import customtkinter as ctk
from tkinter import filedialog, messagebox
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer, CountVectorizer
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import os

# === GUI Settings ===
ctk.set_appearance_mode("light")
ctk.set_default_color_theme("blue")

app = ctk.CTk()
app.title("Кластеризація ключових слів")
app.geometry("1400x900")

all_clusters_text = ""

# === Functions ===
def load_file():
    filepath = filedialog.askopenfilename(filetypes=[("CSV files", "*.csv")])
    entry_file.delete(0, ctk.END)
    entry_file.insert(0, filepath)

def generate_unique_filename(base="clustered_keywords", ext=".csv"):
    i = 1
    while os.path.exists(f"{base}_{i}{ext}"):
        i += 1
    return f"{base}_{i}{ext}"

def copy_to_clipboard(text):
    app.clipboard_clear()
    app.clipboard_append(text)
    app.update()
    messagebox.showinfo("Скопійовано", "Скопійовано в буфер обміну")

def copy_all_clusters():
    global all_clusters_text
    if all_clusters_text.strip():
        copy_to_clipboard(all_clusters_text)
    else:
        messagebox.showwarning("Увага", "Немає даних для копіювання.")

def cluster_keywords():
    global all_clusters_text
    all_clusters_text = ""

    filepath = entry_file.get().strip()
    k_value = entry_k.get().strip()

    if not filepath:
        messagebox.showerror("Помилка", "Будь ласка, оберіть файл з ключовими словами.")
        return
    if not k_value:
        messagebox.showerror("Помилка", "Будь ласка, введіть кількість кластерів.")
        return

    try:
        k = int(k_value)
        if k < 1:
            raise ValueError
    except ValueError:
        messagebox.showerror("Помилка", "Введіть ціле число більше 0.")
        return

    if not os.path.exists(filepath):
        messagebox.showerror("Помилка", "Файл не знайдено.")
        return

    try:
        df = pd.read_csv(filepath)
        required_cols = {'keyword', 'search_volume'}
        if not required_cols.issubset(df.columns):
            raise Exception("Файл повинен містити колонки: keyword та search_volume")

        keywords = df['keyword'].astype(str)
        tfidf = TfidfVectorizer(stop_words='english')
        X = tfidf.fit_transform(keywords)

        kmeans = KMeans(n_clusters=k, random_state=42)
        df['cluster'] = kmeans.fit_predict(X)

        counter = CountVectorizer(stop_words='english')
        cluster_labels = {}
        for cluster_id in sorted(df['cluster'].unique()):
            items = df[df['cluster'] == cluster_id]['keyword'].tolist()
            X_cluster = counter.fit_transform(items)
            freqs = X_cluster.sum(axis=0).A1
            words = counter.get_feature_names_out()
            top = [words[i] for i in freqs.argsort()[::-1][:3]]
            cluster_labels[cluster_id] = ", ".join(top)

        df['cluster_label'] = df['cluster'].map(cluster_labels)

        out_path = generate_unique_filename()
        df.to_csv(out_path, index=False)
        messagebox.showinfo("Готово", f"Збережено у: {out_path}")

        def render_clusters(filter_text=""):
            global all_clusters_text
            all_clusters_text = ""
            for widget in scroll_frame.winfo_children():
                widget.destroy()

            for cluster_id in sorted(df['cluster'].unique()):
                cluster_name = cluster_labels[cluster_id]
                cluster_df = df[df['cluster'] == cluster_id].sort_values(by="search_volume", ascending=False)
                keyword_pairs = list(zip(cluster_df['keyword'], cluster_df['search_volume']))

                if filter_text:
                    keyword_pairs = [(kw, vol) for kw, vol in keyword_pairs if filter_text.lower() in kw.lower()]
                    if not keyword_pairs:
                        continue

                card = ctk.CTkFrame(scroll_frame, fg_color="#f3f3f3", corner_radius=10)
                card.pack(padx=10, pady=10, fill="x")

                top_row = ctk.CTkFrame(card, fg_color="transparent")
                top_row.pack(fill="x", padx=10, pady=(10, 5))

                label = ctk.CTkLabel(top_row, text=f"Кластер {cluster_id}: {cluster_name}", font=("Segoe UI", 14, "bold"), anchor="w")
                label.pack(side="left")

                cluster_text = f"Кластер {cluster_id}: {cluster_name}\n"
                for kw, vol in keyword_pairs:
                    cluster_text += f"• {kw} (пошук: {vol})\n"

                all_clusters_text += cluster_text + "\n"

                copy_btn = ctk.CTkButton(top_row, text="Копіювати", width=90, height=28, command=lambda text=cluster_text: copy_to_clipboard(text))
                copy_btn.pack(side="right")

                for kw, vol in keyword_pairs:
                    lbl = ctk.CTkLabel(card, text=f"• {kw} (пошук: {vol})", font=("Segoe UI", 12), anchor="w")
                    lbl.pack(anchor="w", padx=20)

        render_clusters()

        def on_search_change(*args):
            search_value = search_entry.get()
            render_clusters(search_value)

        search_entry.configure(state="normal")
        search_entry.delete(0, ctk.END)
        search_entry.insert(0, "")
        search_entry.bind("<KeyRelease>", lambda e: on_search_change())

        for widget in chart_frame.winfo_children():
            widget.destroy()

        # --- Top keywords bar chart ---
        top_keywords = df[['keyword', 'search_volume']].sort_values(by='search_volume', ascending=False).head(10)
        fig1, ax1 = plt.subplots(figsize=(6, 4))
        ax1.barh(top_keywords['keyword'][::-1], top_keywords['search_volume'][::-1], color='skyblue')
        ax1.set_title("ТОП ключових слів за обсягом пошуку")
        ax1.set_xlabel("Пошуковий обсяг")
        ax1.set_ylabel("Ключове слово")
        fig1.tight_layout()

        canvas1 = FigureCanvasTkAgg(fig1, master=chart_frame)
        canvas1.draw()
        canvas1.get_tk_widget().pack(fill="x", padx=10, pady=(0, 10))

        # --- 2D Cluster visualization with hover ---
        pca = PCA(n_components=2)
        reduced = pca.fit_transform(X.toarray())

        fig2, ax2 = plt.subplots(figsize=(6, 4))
        scatter = ax2.scatter(reduced[:, 0], reduced[:, 1], c=df['cluster'], cmap='tab10')
        ax2.set_title("Розподіл кластерів у 2D-просторі (PCA)")
        ax2.set_xlabel("Вісь 1 (зменшений вимір)")
        ax2.set_ylabel("Вісь 2 (зменшений вимір)")

        annot = ax2.annotate("", xy=(0, 0), xytext=(15, 15), textcoords="offset points",
                             bbox=dict(boxstyle="round", fc="w"), arrowprops=dict(arrowstyle="->"))
        annot.set_visible(False)

        def update_annot(ind):
            idx = ind["ind"][0]
            pos = scatter.get_offsets()[idx]
            annot.xy = pos
            text = df.iloc[idx]['cluster_label']
            annot.set_text(text)
            annot.get_bbox_patch().set_alpha(0.8)

        def hover(event):
            vis = annot.get_visible()
            if event.inaxes == ax2:
                cont, ind = scatter.contains(event)
                if cont:
                    update_annot(ind)
                    annot.set_visible(True)
                    fig2.canvas.draw_idle()
                elif vis:
                    annot.set_visible(False)
                    fig2.canvas.draw_idle()

        fig2.canvas.mpl_connect("motion_notify_event", hover)
        fig2.tight_layout()

        canvas2 = FigureCanvasTkAgg(fig2, master=chart_frame)
        canvas2.draw()
        canvas2.get_tk_widget().pack(fill="x", padx=10, pady=(0, 10))

    except Exception as e:
        messagebox.showerror("Помилка", str(e))

# === Layout ===
main_frame = ctk.CTkFrame(app)
main_frame.pack(fill="both", expand=True, padx=20, pady=20)

left_frame = ctk.CTkFrame(main_frame, width=900)
left_frame.pack(side="left", fill="both", expand=True, padx=(0, 15))

right_frame = ctk.CTkFrame(main_frame, width=500)
right_frame.pack(side="right", fill="both")

form_frame = ctk.CTkFrame(left_frame)
form_frame.pack(padx=0, pady=(0, 10), fill="x")

# File input
label_file = ctk.CTkLabel(form_frame, text="Файл з ключовими словами")
label_file.grid(row=0, column=0, sticky="w", padx=10)
entry_file = ctk.CTkEntry(form_frame, width=350)
entry_file.grid(row=1, column=0, padx=10, pady=(0, 10), sticky="w")
button_browse = ctk.CTkButton(form_frame, text="Огляд", command=load_file, width=120)
button_browse.grid(row=1, column=1, padx=5, pady=(0, 10), sticky="w")

# Cluster count input
label_k = ctk.CTkLabel(form_frame, text="Кількість кластерів")
label_k.grid(row=2, column=0, sticky="w", padx=10)
entry_k = ctk.CTkEntry(form_frame, width=480)
entry_k.insert(0, "3")
entry_k.grid(row=3, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")

# Search input
label_search = ctk.CTkLabel(form_frame, text="Пошук за ключовим словом")
label_search.grid(row=4, column=0, sticky="w", padx=10)
search_entry = ctk.CTkEntry(form_frame, width=480)
search_entry.grid(row=5, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")

# Cluster button
button_cluster = ctk.CTkButton(form_frame, text="Кластеризувати", command=cluster_keywords, width=480)
button_cluster.grid(row=6, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")

# Copy all clusters button
copy_all_btn = ctk.CTkButton(form_frame, text="Копіювати всі кластери", command=copy_all_clusters, width=480)
copy_all_btn.grid(row=7, column=0, columnspan=2, padx=10, pady=(0, 10), sticky="w")

scroll_frame = ctk.CTkScrollableFrame(left_frame, width=850, height=600)
scroll_frame.pack(padx=0, pady=(0, 10), fill="both", expand=True)

chart_frame = ctk.CTkFrame(right_frame, width=450)
chart_frame.pack(padx=10, pady=10, fill="both", expand=True)

app.mainloop()
